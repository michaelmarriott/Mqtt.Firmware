import json
import sys
from datetime import datetime

class LoggerMoverModule:

  def __init__(self, config, client, logger):
    self.config = config
    self.client = client
    self.logger = logger
    self.mqtt_username = config["mqtt_username"]

  def onMessage(self, id, topic,body, callback):
    print("LoggerMoverModule: onMessage")
    if topic == "file":
      jbody = json.loads(body)
      fileName = jbody["name"]
      if fileName.find("log"):
        file = open("/home/pi/sensor/"+fileName, "rb")  
        filestring = file.read()      
        byteArray = bytes(filestring) 
        self.client.publish("tele/"+self.mqtt_username+"/FILE", byteArray)
      else:
         self.client.publish("tele/"+self.mqtt_username+"/FILE", "")
    return

  def onConfigChange(self,newconfig):
    self.config = newconfig
    

